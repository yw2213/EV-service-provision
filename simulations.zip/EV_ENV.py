#!/usr/bin/env python
# coding: utf-8
from __future__ import division
import pandas as pd
import numpy as np
import random
import time
from pyomo.environ import *
from pyomo.opt import SolverFactory
import gym
from gym import spaces, logger
from random import choice
from mlxtend.preprocessing import one_hot
import scipy.stats as stats

class make_env(gym.Env):

    def __init__(self):

        # daily main grid price [£/kWh] and carbon intensity [gCO2/kWh]
        self.price_data = pd.read_excel('data.xlsx', sheet_name='price', index_col=0).values[0]
        self.fr_data = pd.read_excel('data.xlsx', sheet_name='fr', index_col=0).values[0]
        self.pv_data = pd.read_excel('data.xlsx', sheet_name='pv', index_col=0).values
        self.load_data = pd.read_excel('data.xlsx', sheet_name='load', index_col=0).values*0.8
        self.ev_data = pd.read_excel('data.xlsx', sheet_name='ev', index_col=0).values

        # technical parameters
        self.net_single = pd.read_excel('system.xlsx', sheet_name=None)

        # 2 pvs and 1 wd capacity
        self.pv_cap = self.net_single['pv']['p_max'].values

        # 2 DGs data
        self.DG_bus = self.net_single['gen']['bus'].values
        self.DG_max_p = self.net_single['gen']['max_p'].values
        self.DG_max_q = self.net_single['gen']['max_q'].values
        self.DG_min_q = self.net_single['gen']['min_q'].values
        self.DG_cost = self.net_single['gen']['cost_linear'].values

        # 3 EVs data
        self.EV_ini_bus = self.net_single['ev']['bus'].values
        self.EV_max_p = self.net_single['ev']['max_p'].values
        self.EV_max_e = self.net_single['ev']['max_e'].values
        self.EV_min_soc = self.net_single['ev']['min_soc'].values
        self.EV_max_soc = self.net_single['ev']['max_soc'].values
        self.EV_ini_soc = self.net_single['ev']['ini_soc'].values # noise
        self.EV_effi = self.net_single['ev']['effi'].values
        self.EV_Apparent = self.net_single['ev']['apparent'].values

        # Network base params
        self.Net_base = self.net_single["par"]["base"].values
        self.Net_ref_bus = self.net_single["par"]["refnode"].values
        self.Net_volt = self.net_single["par"]["volt"].values
        self.Net_va_degree = self.net_single["par"]["va_degree"].values
        
        # line
        self.n_line = self.net_single["line"].shape[0]
        self.Line_max_f = self.net_single["line"]['max_f'].values
        self.Line_from = self.net_single["line"]['from_bus'].values
        self.Line_to = self.net_single["line"]['to_bus'].values
        self.Line_g = self.net_single["line"]['g'].values
        self.Line_b = self.net_single["line"]['b'].values
        self.Line_r = self.net_single["line"]['r'].values
        self.Line_x = self.net_single["line"]['x'].values

        # 6 Buses params
        self.Bus_name = self.net_single['bus']['name'].values
        self.Bus_min_v = self.net_single['bus']['v_min'].values
        self.Bus_max_v = self.net_single['bus']['v_max'].values
        self.Bus_v = self.net_single['bus']['v'].values
        self.Bus_de = self.net_single['bus']['de'].values

        # Locations of 2 charging stations, 3 load, 1 pv
        self.ED_bus = self.net_single['load']['bus'].values
        self.PV_bus = self.net_single['pv']['bus'].values

        # state, line outages
        self.EV_soc = None
        self.EV_bus = None
        self.n_ev = 10
        self.n_station = 2
        self.n_ed = 8
        self.n_pv = 3 # 2 pvs and 1 wd
        self.n_dg = 2
        self.n_bus = 15
        self.n_step = 24
        self.type = self.net_single['load']['type'].values
        self.shed = self.net_single['load']['shed'].values

        self.ED_data = np.concatenate([self.load_data], axis=0).reshape([self.n_ed,self.n_step])
        self.PV_data = np.concatenate([self.pv_data], axis=0).reshape([self.n_pv, self.n_step])
        self.Bus_loc = np.concatenate([self.ev_data], axis=0).reshape([self.n_ev, self.n_step])

        zip_ed = zip(self.ED_bus, self.ED_data)
        zip_pv = zip(self.PV_bus, self.PV_data)
        self.ED_dic = dict(zip_ed)
        self.PV_dic = dict(zip_pv)
        
    # ------- ENV initilization -------
    def reset(self):

        # np.random.seed(1)
        uncertain_pv = np.random.uniform(-0.1, 0.1, (3, 24))
        uncertain_load = np.random.uniform(-0.1, 0.1, (8, 24))
        self.PV_data = self.PV_data*(1+uncertain_pv)
        self.ED_data = self.ED_data*(1+uncertain_load)

        self.step = 0

        self.EV_soc = self.EV_ini_soc
        self.EV_bus = self.EV_ini_bus.copy()
        self.state = []

        for i in range(self.n_ev):
            for b in range(self.n_bus):
                # nodal load
                if self.EV_bus[i] in self.ED_bus:
                    Bus_load_p = self.ED_dic[self.EV_bus[i]][0]
                    Bus_load_q = self.ED_dic[self.EV_bus[i]][0]*self.type[self.EV_bus[i]]
                else:
                    Bus_load_p = 0
                    Bus_load_q = 0
                # nodal pv
                if self.EV_bus[i] in self.PV_bus:
                    Bus_pv_p = self.PV_dic[self.EV_bus[i]][0]
                else:
                    Bus_pv_p = 0

            # combine all info
            obs = [self.step, self.EV_soc[i], self.EV_bus[i], Bus_load_p, Bus_load_q, Bus_pv_p,self.PV_data[0, self.step], self.PV_data[1, self.step], self.PV_data[2, self.step], self.price_data[self.step],self.fr_data[self.step]]
            self.state.append(obs)

        return self.state
    
    # ------ ACOPF - LP --------
    def ACOPF_model(self, ev_P, ev_Q):
        
        t = self.step  # hour index
        pv_t = self.PV_data[:,t]
        ed_t = self.ED_data[:,t]

        model = ConcreteModel()

        model.B = Set (initialize=[b for b in range (self.n_bus)], doc='Buses', ordered=True)
        model.LI = Set (initialize=[l for l in range (self.n_line)], doc='Lines', ordered=True)
        model.EV = Set (initialize=[i for i in range (self.n_ev)], doc='EVs', ordered=True)
        model.G = Set (initialize=[g for g in range (self.n_dg)], doc='Generators', ordered=True)
        model.B_pv = Set (initialize=[g for g in range (self.n_pv)], doc='PVs', ordered=True)
        model.LO = Set (initialize=[d for d in range (self.n_ed)], doc='Loads', ordered=True)
        model.Grid = Set (initialize=[0], doc='Grid', ordered=True)

        # Scalars
        model.base = Param (initialize=self.Net_base[0])
        model.ref = Param (initialize=self.Net_ref_bus[0])
        model.vadegree = Param (initialize=self.Net_va_degree[0])

        # Variables - AC network
        model.ga = Var (model.G, domain=NonNegativeReals)
        model.gr = Var (model.G, domain=Reals)
        model.gr_ab = Var (model.G, domain=Reals)
        model.fas = Var (model.LI, domain=Reals)
        model.far = Var (model.LI, domain=Reals)
        model.frs = Var (model.LI, domain=Reals)
        model.frr = Var (model.LI, domain=Reals)
        model.pv_ga = Var (model.B_pv, domain=NonNegativeReals)
        model.pv_gr = Var (model.B_pv, domain=Reals)
        model.load_da = Var (model.LO, domain=NonNegativeReals)
        model.load_dr = Var (model.LO, domain=NonNegativeReals)

        # Variables - Grid
        model.P_grid = Var (model.Grid, domain=Reals)
        model.Q_grid = Var (model.Grid, domain=Reals)
        model.volt = Var (model.B, domain=NonNegativeReals)
        model.phi = Var (model.B, domain=Reals)
        model.dual = Suffix (direction=Suffix.IMPORT_EXPORT)

        # Objective function
        def _obj_(model):
            return + sum (self.price_data[t] * model.P_grid[k] for k in range(0, 1, 1))\
                   + sum (0.1 * self.price_data[t] * model.Q_grid[k] for k in range(0, 1, 1))\
                   + sum (self.DG_cost[g] * model.ga[g] for g in model.G)\
                   + sum (0.1 * self.DG_cost[g] * model.gr_ab[g] for g in model.G)\
                   - sum (self.price_data[t] * self.shed[d] * model.load_da[d] for d in model.LO)\
                   - sum (0.1 * self.price_data[t] * self.shed[d] * model.load_dr[d] for d in model.LO)
        model.objective = Objective (rule=_obj_, sense=minimize)

        # DG constraints
        def _g_a_p_UB_(model, g):
            return model.ga[g] <= self.DG_max_p[g]
        model.g_a_p_UB_ = Constraint (model.G, rule=_g_a_p_UB_)

        def _g_r_p_UB_(model, g):
            return model.gr[g] <= self.DG_max_q[g]
        model.g_r_p_UB_ = Constraint (model.G, rule=_g_r_p_UB_)

        def _g_r_p_LB_(model, g):
            return model.gr[g] >= self.DG_min_q[g]
        model.g_r_p_LB_ = Constraint (model.G, rule=_g_r_p_LB_)

        def _absolute_1(model, g):
            return model.gr_ab[g] >= model.gr[g]
        model.absolute_1 = Constraint (model.G, rule=_absolute_1)

        def _absolute_2(model, g):
            return model.gr_ab[g] >= -model.gr[g]
        model.absolute_2 = Constraint (model.G, rule=_absolute_2)

        # PV generation constraint
        def _pv_ga_p_UB_(model, g):
            return model.pv_ga[g] <= pv_t[g] * self.pv_cap[g]
        model.pv_ga_p_UB_ = Constraint (model.B_pv, rule=_pv_ga_p_UB_)

        # PV generation constraint
        def _pv_gr_(model, g):
            return model.pv_gr[g] <= pv_t[g] * 10000
        model.pv_gr_ = Constraint (model.B_pv, rule=_pv_gr_)

        # PV capacity constraints
        def _pv_flow_send_UB_(model, g):
            return model.pv_ga[g] <= self.pv_cap[g]
        model.pv_flow_send_UB_ = Constraint (model.B_pv, rule=_pv_flow_send_UB_)

        def _pv_flow_send_LB_(model, g):
            return model.pv_ga[g] >= - self.pv_cap[g]
        model.pv_flow_send_LB_ = Constraint (model.B_pv, rule=_pv_flow_send_LB_)

        def _pv_flow_rsend_UB_(model, g):
            return model.pv_gr[g] <= self.pv_cap[g]
        model.pv_flow_rsend_UB_ = Constraint (model.B_pv, rule=_pv_flow_rsend_UB_)

        def _pv_flow_rsend_LB_(model, g):
            return model.pv_gr[g] >= - self.pv_cap[g]
        model.pv_flow_rsend_LB_ = Constraint (model.B_pv, rule=_pv_flow_rsend_LB_)

        def _pv_flow_tsend_UB_(model, g):
            return model.pv_ga[g] + model.pv_gr[g] <= 1.414 * self.pv_cap[g]
        model.pv_flow_tsend_UB_ = Constraint (model.B_pv, rule=_pv_flow_tsend_UB_)

        def _pv_flow_tsend_LB_(model, g):
            return model.pv_ga[g] + model.pv_gr[g] >= - 1.414 * self.pv_cap[g]
        model.pv_flow_tsend_LB_ = Constraint (model.B_pv, rule=_pv_flow_tsend_LB_)

        def _pv_flow_ttsend_UB_(model, g):
            return model.pv_ga[g] - model.pv_gr[g] <= 1.414 * self.pv_cap[g]
        model.pv_flow_ttsend_UB_ = Constraint (model.B_pv, rule=_pv_flow_ttsend_UB_)

        def _pv_flow_ttsend_LB_(model, g):
            return model.pv_ga[g] - model.pv_gr[g] >= - 1.414 * self.pv_cap[g]
        model.pv_flow_ttsend_LB_ = Constraint (model.B_pv, rule=_pv_flow_ttsend_LB_)

        # Nodal constraints
        def _volt_UB_(model, b):
            return model.volt[b] <= self.Bus_max_v[b]
        model.volt_UB_ = Constraint (model.B, rule=_volt_UB_)
        
        def _volt_LB_(model, b):
            return model.volt[b] >= self.Bus_min_v[b]
        model.volt_LB_ = Constraint (model.B, rule=_volt_LB_)
        
        # Load shedding constraint
        def _load_da_UB_(model, d):
            return model.load_da[d] <= ed_t[d]
        model.load_da_UB_ = Constraint (model.LO, rule=_load_da_UB_)
        
        def _load_dr_UB_(model, d):
            return model.load_dr[d] <= ed_t[d]*self.type[d]
        model.load_dr_UB_ = Constraint (model.LO, rule=_load_dr_UB_)

        # Constraints - AC network
        def _node_balance_active_(model, b):
            return - sum (model.ga[g] for g in model.G if self.DG_bus[g] == self.Bus_name[b])\
                   - sum (model.P_grid[k] for k in range(0, 1, 1) if 0 == self.Bus_name[b])\
                   + sum (ev_P[i] for i in model.EV if self.EV_bus[i] == self.Bus_name[b])\
                   + sum (model.load_da[d] for d in model.LO if self.ED_bus[d] == self.Bus_name[b])\
                   + sum (model.fas[l] for l in model.LI if self.Line_from[l] == self.Bus_name[b])\
                   + sum (model.far[l] for l in model.LI if self.Line_to[l] == self.Bus_name[b])\
                   - sum (model.pv_ga[g] for g in model.B_pv if self.PV_bus[g] == self.Bus_name[b]) == 0
        model.NodeBalanceActive = Constraint (model.B, rule=_node_balance_active_)

        def _node_balance_reactive_(model, b):  # need a change?
            return - sum (model.gr[g] for g in model.G if self.DG_bus[g] == self.Bus_name[b])\
                   - sum (model.Q_grid[k] for k in range(0, 1, 1) if 0 == self.Bus_name[b])\
                   + sum (ev_Q[i] for i in model.EV if self.EV_bus[i] == self.Bus_name[b])\
                   + sum (model.load_dr[d] for d in model.LO if self.ED_bus[d] == self.Bus_name[b])\
                   + sum (model.frs[l] for l in model.LI if self.Line_from[l] == self.Bus_name[b])\
                   + sum (model.frr[l] for l in model.LI if self.Line_to[l] == self.Bus_name[b])\
                   - sum (model.pv_gr[g] for g in model.B_pv if self.PV_bus[g] == self.Bus_name[b]) == 0
        model.NodeBalanceReactive = Constraint (model.B, rule=_node_balance_reactive_)

        def _line_active_send_(model, l):
            return model.fas[l] == model.base * (self.Line_g[l] * (sum (
                model.volt[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                model.volt[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) / 2 \
                                                    - self.Line_b[l] * (sum (
                        model.phi[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        model.phi[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) \
                                                    + self.Line_g[l] * (sum (
                        self.Bus_de[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        self.Bus_de[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) * (sum (
                        model.phi[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        model.phi[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) \
                                                    + self.Line_g[l] * (sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) / (sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) + sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) * (sum (
                        model.volt[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        model.volt[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) \
                                                    - self.Line_g[l] / 2 * ((sum (
                        self.Bus_de[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        self.Bus_de[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) ** 2 + (sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) ** 2))
        model.LinePhaseActiveSend_ = Constraint (model.LI, rule=_line_active_send_)

        def _line_active_receive_(model, l):
            return model.far[l] == model.base * (self.Line_g[l] * (sum (
                model.volt[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                model.volt[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) / 2 \
                                                    - self.Line_b[l] * (sum (
                        model.phi[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        model.phi[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) \
                                                    + self.Line_g[l] * (sum (
                        self.Bus_de[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        self.Bus_de[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) * (sum (
                        model.phi[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        model.phi[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) \
                                                    + self.Line_g[l] * (sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) / (sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) + sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) * (sum (
                        model.volt[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        model.volt[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) \
                                                    - self.Line_g[l] / 2 * ((sum (
                        self.Bus_de[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        self.Bus_de[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) ** 2 + (sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) ** 2))
        model.LinePhaseActiveReceive_ = Constraint (model.LI, rule=_line_active_receive_)

        def _line_reactive_send_(model, l):
            return model.frs[l] == model.base * ((-self.Line_b[l]) * (sum (
                model.volt[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                model.volt[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) / 2 \
                                                    - self.Line_g[l] * (sum (
                        model.phi[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        model.phi[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) \
                                                    + (-self.Line_b[l]) * (sum (
                        self.Bus_de[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        self.Bus_de[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) * (sum (
                        model.phi[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        model.phi[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) \
                                                    + (-self.Line_b[l]) * (sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) / (sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) + sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) * (sum (
                        model.volt[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        model.volt[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) \
                                                    - (-self.Line_b[l]) / 2 * ((sum (
                        self.Bus_de[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        self.Bus_de[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) ** 2 + (sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b]) - sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b])) ** 2))
        model.LinePhaseReactiveSend_ = Constraint (model.LI, rule=_line_reactive_send_)

        def _line_reactive_receive_(model, l):
            return model.frr[l] == model.base * ((-self.Line_b[l]) * (sum (
                model.volt[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                model.volt[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) / 2
                                                    - self.Line_g[l] * (sum (
                        model.phi[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        model.phi[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) \
                                                    + (-self.Line_b[l]) * (sum (
                        self.Bus_de[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        self.Bus_de[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) * (sum (
                        model.phi[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        model.phi[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) \
                                                    + (-self.Line_b[l]) * (sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) / (sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) + sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) * (sum (
                        model.volt[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        model.volt[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) \
                                                    - (-self.Line_b[l]) / 2 * ((sum (
                        self.Bus_de[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        self.Bus_de[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) ** 2 + (sum (
                        self.Bus_v[b] for b in model.B if self.Line_to[l] == self.Bus_name[b]) - sum (
                        self.Bus_v[b] for b in model.B if self.Line_from[l] == self.Bus_name[b])) ** 2))
        model.LinePhaseReactiveReceive_ = Constraint (model.LI, rule=_line_reactive_receive_)

        # Line constraints - sending
        def _line_flow_send_UB_(model, l):
            return model.fas[l] <= self.Line_max_f[l]
        model.line_flow_send_UB_ = Constraint (model.LI, rule=_line_flow_send_UB_)

        def _line_flow_send_LB_(model, l):
            return model.fas[l] >= - self.Line_max_f[l]
        model.line_flow_send_LB_ = Constraint (model.LI, rule=_line_flow_send_LB_)

        def _line_flow_rsend_UB_(model, l):
            return model.frs[l] <= self.Line_max_f[l]
        model.line_flow_rsend_UB_ = Constraint (model.LI, rule=_line_flow_rsend_UB_)

        def _line_flow_rsend_LB_(model, l):
            return model.frs[l] >= - self.Line_max_f[l]
        model.line_flow_rsend_LB_ = Constraint (model.LI, rule=_line_flow_rsend_LB_)

        def _line_flow_tsend_UB_(model, l):
            return model.fas[l] + model.frs[l] <= 1.414 * self.Line_max_f[l]
        model.line_flow_tsend_UB_ = Constraint (model.LI, rule=_line_flow_tsend_UB_)

        def _line_flow_tsend_LB_(model, l):
            return model.fas[l] + model.frs[l] >= - 1.414 * self.Line_max_f[l]
        model.line_flow_tsend_LB_ = Constraint (model.LI, rule=_line_flow_tsend_LB_)

        def _line_flow_ttsend_UB_(model, l):
            return model.fas[l] - model.frs[l] <= 1.414 * self.Line_max_f[l]
        model.line_flow_ttsend_UB_ = Constraint (model.LI, rule=_line_flow_ttsend_UB_)

        def _line_flow_ttsend_LB_(model, l):
            return model.fas[l] - model.frs[l] >= - 1.414 * self.Line_max_f[l]
        model.line_flow_ttsend_LB_ = Constraint (model.LI, rule=_line_flow_ttsend_LB_)

        # Line constraints - receive
        def _line_flow_receive_UB_(model, l):
            return model.far[l] <= self.Line_max_f[l]
        model.line_flow_receive_UB_ = Constraint (model.LI, rule=_line_flow_receive_UB_)

        def _line_flow_receive_LB_(model, l):
            return model.far[l] >= - self.Line_max_f[l]
        model.line_flow_receive_LB_ = Constraint (model.LI, rule=_line_flow_receive_LB_)

        def _line_flow_rreceive_UB_(model, l):
            return model.frr[l] <= self.Line_max_f[l]
        model.line_flow_rreceive_UB_ = Constraint (model.LI, rule=_line_flow_rreceive_UB_)

        def _line_flow_rreceive_LB_(model, l):
            return model.frr[l] >= - self.Line_max_f[l]
        model.line_flow_rreceive_LB_ = Constraint (model.LI, rule=_line_flow_rreceive_LB_)

        def _line_flow_treceive_UB_(model, l):
            return model.far[l] + model.frr[l] <= 1.414 * self.Line_max_f[l]
        model.line_flow_treceive_UB_ = Constraint (model.LI, rule=_line_flow_treceive_UB_)

        def _line_flow_treceive_LB_(model, l):
            return model.far[l] + model.frr[l] >= -1.414 * self.Line_max_f[l]
        model.line_flow_treceive_LB_ = Constraint (model.LI, rule=_line_flow_treceive_LB_)

        def _line_flow_ttreceive_UB_(model, l):
            return model.far[l] - model.frr[l] <= 1.414 * self.Line_max_f[l]
        model.line_flow_ttreceive_UB_ = Constraint (model.LI, rule=_line_flow_ttreceive_UB_)

        def _line_flow_ttreceive_LB_(model, l):
            return model.far[l] - model.frr[l] >= - 1.414 * self.Line_max_f[l]
        model.line_flow_ttreceive_LB_ = Constraint (model.LI, rule=_line_flow_ttreceive_LB_)

        return model
    
    # ------------ ENV step by step ---------------
    def env_step(self, action):

        P_pow = np.array(action)[:,0]
        Q_pow = np.array(action)[:,1]
        FR_pow = np.array(action)[:,2]

        # Calculate EVs charging power (active and reactive)
        charge, discharge, reactive, reserve = [], [], [], []
        for i in range(self.n_ev):
            charge.append(max(0,min(P_pow[i]*self.EV_max_p[i],(self.EV_max_soc[i]-self.EV_soc[i])*self.EV_max_e[i]/self.EV_effi[i])))
            discharge.append(min(0, max(P_pow[i]*self.EV_max_p[i], (self.EV_min_soc[i]-self.EV_soc[i]*self.EV_max_e[i]*self.EV_effi[i]))))
            reactive.append(Q_pow[i]*np.sqrt((self.EV_Apparent[i])**2 - (charge[i]+discharge[i])**2))
            reserve.append((FR_pow[i]+1)/2*(self.EV_max_p[i] + (charge[i]+discharge[i])))

        # Solve AC-OPF, Generate reward, next state
        power_ev = []
        re_power_ev = []
        reserve_ev = []
        for i in range(self.n_ev):
            if self.EV_bus[i] == 3 or self.EV_bus[i] == 7:
                power_ev.append(charge[i]+discharge[i])
                re_power_ev.append(reactive[i])
                reserve_ev.append(reserve[i])
            else:
                charge[i] = 0
                discharge[i] = 0
                reactive[i] = 0
                reserve[i] = 0
                power_ev.append(0)
                re_power_ev.append(0)
                reserve_ev.append(0)

        # Update next SoC after charging discharging
        SoC_next = np.zeros(self.n_ev)
        for i in range(self.n_ev):
            if self.EV_bus[i] == 3 or self.EV_bus[i] == 7:
                SoC_next[i] = self.EV_soc[i] + (charge[i]*self.EV_effi[i] + discharge[i]/self.EV_effi[i])/self.EV_max_e[i]
            else:
                SoC_next[i] = max(0, (self.EV_soc[i] - self.EV_max_p[i]/(self.EV_max_e[i]*self.EV_effi[i])))

        # solve AC-OPF
        inst = self.ACOPF_model(ev_P=power_ev, ev_Q=re_power_ev)
        solver = SolverFactory('gurobi', solver_io="python")
        result = solver.solve(inst)

        #infeasible solutions get penalty
        if str (result.solver.status) is 'warning':
            penalty = -100
        else:
            penalty = 0

        # Update System LMPs Voltage
        P_LMP, Q_LMP, Voltage_N = [], [], []
        for b in range(self.n_bus):
            P_LMP.append(-value(inst.dual[inst.NodeBalanceActive[b]]))
            Q_LMP.append(-value(inst.dual[inst.NodeBalanceReactive[b]]))
            Voltage_N.append(np.sqrt(value(inst.volt[b])))
        OPF_LMP = [[P_LMP[b],Q_LMP[b]] for b in range(self.n_bus)]
        
        # Update EV LMPs 
        P_LMPC, Q_LMPC = [], []
        for i in range(self.n_ev):
            if self.EV_bus[i] == 100:
                P_LMPC.append(0)
                Q_LMPC.append(0)
            else:
                P_LMPC.append(P_LMP[self.EV_bus[i]])
                Q_LMPC.append(Q_LMP[self.EV_bus[i]])
        EV_LMPC = [[P_LMPC[i],Q_LMPC[i]] for i in range(self.n_ev)]
        
        # Load shedding quantity
        load_shedding_tot = 0
        for d in range(self.n_ed):
            load_shedding_tot += self.ED_data[d,self.step] - value(inst.load_da[d])
                      
        # Reward function
        reward_ev = np.zeros(self.n_ev)
        for i in range(self.n_ev):
            if power_ev[i] >= 0:
                if value(inst.P_grid[0]) >= 0:
                    reward_ev[i] = - P_LMPC[i] * power_ev[i] - Q_LMPC[i] * reactive[i] + self.fr_data[self.step]*reserve[i] + penalty
                else:
                    reward_ev[i] = - 0*P_LMPC[i] * power_ev[i] - Q_LMPC[i] * reactive[i] + self.fr_data[self.step]*reserve[i] + penalty
            else:
                reward_ev[i] = - P_LMPC[i] * power_ev[i] - Q_LMPC[i] * reactive[i] + self.fr_data[self.step]*reserve[i] + penalty
        
        # Update Next State
        self.step += 1
        self.EV_soc = SoC_next 

        # [time, SoC(50%), ev_bus, load, pv, lmps]
        self.state = []
        for i in range(self.n_ev):
            #location update
            if self.step == 24:
                self.EV_bus[i] = self.Bus_loc[i,0]
            else:
                self.EV_bus[i] = self.Bus_loc[i,self.step]
            # nodal load
            if self.EV_bus[i] in self.ED_bus:
                if self.step == 24:
                    Bus_load_p = self.ED_dic[self.EV_bus[i]][0]
                    Bus_load_q = self.ED_dic[self.EV_bus[i]][0] * self.type[self.EV_bus[i]]
                else:
                    Bus_load_p = self.ED_dic[self.EV_bus[i]][self.step]
                    Bus_load_q = self.ED_dic[self.EV_bus[i]][self.step] * self.type[self.EV_bus[i]]
            else:
                Bus_load_p = 0
                Bus_load_q = 0

            # nodal pv
            if self.EV_bus[i] in self.PV_bus:
                if self.step == 24:
                    Bus_pv_p = self.PV_dic[self.EV_bus[i]][0]
                else:
                    Bus_pv_p = self.PV_dic[self.EV_bus[i]][self.step]
            else:
                Bus_pv_p = 0

            # combine all info
            if self.step == 24:
                obs = [self.step, self.EV_soc[i], self.EV_bus[i], Bus_load_p, Bus_load_q, Bus_pv_p,self.PV_data[0, 0], self.PV_data[1, 0], self.PV_data[2, 0],self.price_data[0],self.fr_data[0]]
            else:
                obs = [self.step, self.EV_soc[i], self.EV_bus[i], Bus_load_p, Bus_load_q, Bus_pv_p,self.PV_data[0, self.step], self.PV_data[1, self.step], self.PV_data[2, self.step],self.price_data[self.step],self.fr_data[self.step]]
            self.state.append(obs)

        return self.state, reward_ev, power_ev, re_power_ev, reserve_ev, load_shedding_tot, EV_LMPC, OPF_LMP, Voltage_N

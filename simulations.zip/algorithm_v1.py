#!/usr/bin/env python
# coding: utf-8
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
# tf.compat.v1.disable_eager_execution()
import numpy as np
import pandas as pd
import random
import time
import gym
import matplotlib.pyplot as plt
"""Imports Environment"""
from EV_ENV import make_env

class PPO(object):

    def __init__(self, name):
        self.name = name
        self.sess = tf.Session()
        
        # placeholder
        self.tfs = tf.placeholder(tf.float32, [None, S_DIM], 'state')
        self.tfa = tf.placeholder(tf.float32, [None, A_DIM], 'action')
        self.tfadv = tf.placeholder(tf.float32, [None, 1], 'advantage')
        self.tfdc_r = tf.placeholder(tf.float32, [None, 1], 'discounted_r')
        self.tflmp = tf.placeholder(tf.float32, [None, 2], 'lmp')

        # variables
        with tf.variable_scope(self.name + 'actor'):
            self.pi = self._build_anet(scope='pi', trainable=True)
            self.oldpi = self._build_anet(scope='oldpi', trainable=False)
        with tf.variable_scope(self.name + 'critic'):
            self.v = self._build_cnet(scope='theta', trainable=True)
            
        # networks parameters
        self.pi_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=self.name + 'actor/pi')
        self.oldpi_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=self.name + 'actor/oldpi')
        self.v_params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=self.name + 'critic/theta')
        
        # actor loss
        self.sample_op = tf.squeeze(self.pi.sample(1), axis=0)       # choosing action
        self.update_oldpi_op = [oldp.assign(p) for p, oldp in zip(self.pi_params, self.oldpi_params)]
        self.ratio = self.pi.prob(self.tfa) / (self.oldpi.prob(self.tfa) + 1e-5)
        self.surr = self.ratio * self.tfadv
        self.aloss = -tf.reduce_mean(tf.minimum(
            self.surr, tf.clip_by_value(self.ratio, 1.-EPSILON, 1.+EPSILON)*self.tfadv))
        self.atrain_op = tf.train.AdamOptimizer(A_LR).minimize(self.aloss)
        
        # critic loss
        self.advantage = self.tfdc_r - self.v
        self.closs = tf.reduce_mean(tf.square(self.advantage))
        self.ctrain_op = tf.train.AdamOptimizer(C_LR).minimize(self.closs, var_list=self.v_params)
            
        # sess run all variables
        self.sess.run(tf.global_variables_initializer())

    def update(self, s, a, r, lmp):
        # copy pi to old pi
        self.sess.run(self.update_oldpi_op)
        adv = self.sess.run(self.advantage, {self.tfs: s, self.tfdc_r: r, self.tflmp: lmp})
        # update actor
        a = a.reshape((BATCH,A_DIM))
        [self.sess.run(self.atrain_op, {self.tfs: s, self.tfa: a, self.tfadv: adv}) for _ in range(A_UPDATE_STEPS)]
        # update critic
        [self.sess.run(self.ctrain_op, {self.tfs: s, self.tfdc_r: r, self.tflmp: lmp}) for _ in range(C_UPDATE_STEPS)]

    def _build_anet(self, scope, trainable):
        with tf.variable_scope(scope):
            l1 = tf.layers.dense(self.tfs, 100, tf.nn.relu, trainable=trainable)
            l2 = tf.layers.dense(l1, 100, tf.nn.relu, trainable=trainable)
            mu = tf.layers.dense(l2, A_DIM, tf.nn.tanh, trainable=trainable)
            sigma = tf.layers.dense(l2, A_DIM, tf.nn.softplus, trainable=trainable)
            norm_dist = tf.distributions.Normal(loc=mu, scale=sigma)
        return norm_dist
    
    def _build_cnet(self, scope, trainable):
        with tf.variable_scope(scope):
            init_b = tf.constant_initializer(0.1)
            n_l1 = 100 
            w1_s = tf.get_variable('w1_s', [S_DIM, n_l1], trainable=trainable)
            w1_lmp = tf.get_variable('w1_lmp', [2, n_l1], trainable=trainable)
            b1 = tf.get_variable('b1', [1, n_l1], initializer=init_b, trainable=trainable)
            l1 = tf.nn.relu(tf.matmul(self.tfs, w1_s) + tf.matmul(self.tflmp, w1_lmp) + b1) 
            l2 = tf.layers.dense(l1, 100, tf.nn.relu, trainable=trainable)
            v = tf.layers.dense(l2, 1, trainable=trainable)
        return v

    def choose_action(self, s):
        s = s[np.newaxis, :]
        a = self.sess.run(self.sample_op, {self.tfs: s})[0]
        return np.clip(a, -1, 1)

    def get_v(self, s, lmp):
        if s.ndim < 2: 
            s = s[np.newaxis, :]
            lmp = lmp[np.newaxis, :]
        return self.sess.run(self.v, {self.tfs: s, self.tflmp: lmp})[0, 0]

np.random.seed(random.randint(0,1e5))
tf.set_random_seed(random.randint(0,1e5))

EP_MAX = 500
EP_LEN = 24
GAMMA = 0.99
A_LR, C_LR = 0.0001, 0.001
BATCH = 24
A_UPDATE_STEPS = 2
C_UPDATE_STEPS = 2
EPSILON = 0.2
# ENV
S_DIM, A_DIM = 11, 3
env = make_env()
# define agents
n_agent = 10
name = 'ps'
ppo = PPO(name)

all_ep_r = []
for ep in range(EP_MAX):
    t2 = time.time()
    s = env.reset()
    buffer_s, buffer_a, buffer_r = [[] for _ in range(n_agent)], [[] for _ in range(n_agent)], [[] for _ in range(n_agent)]
    buffer_lmp = [[] for _ in range(n_agent)]
    ep_r = [0 for _ in range(n_agent)]
    load_shedding_epi = 0
    
    for t in range(EP_LEN):
        # generate actions
        a = []
        for i in range(n_agent):
            ai = ppo.choose_action(np.array(s[i]))
            a.append(ai)
            
        # send actions to env
        s_, r, act_pow, react_pow, reserve_pow, load_shedding_step, LmpI, LmpS, VolS = env.env_step(a)

        # store buffer
        for i in range(n_agent):
            buffer_s[i].append(s[i])
            buffer_a[i].append(a[i])
            buffer_lmp[i].append(LmpI[i])
            buffer_r[i].append((r[i]+0)/1)
        
        # update new state, accumlate reward
        s = s_
        load_shedding_epi += load_shedding_step
        for i in range(n_agent):
            ep_r[i] += r[i]

        # update network
        if (t+1) % BATCH == 0 or t == EP_LEN-1:
            for i in range(n_agent):
                # advantage
                v_s_ = ppo.get_v(np.array(s[i]), np.array(LmpI[i]))
                discounted_r = []
                j = 0
                for r in buffer_r[i][::-1]:
                    if j == 0:
                        v_s_ = r
                    else:
                        v_s_ = r + GAMMA * v_s_
                    j+=1
                    discounted_r.append(v_s_)
                discounted_r.reverse()
                # train
                bs, ba, br = np.vstack(buffer_s[i]), np.vstack(buffer_a[i]), np.array(discounted_r)[:, np.newaxis]
                blmp = np.vstack(buffer_lmp[i])
                ppo.update(bs, ba, br, blmp)
                buffer_s[i], buffer_a[i], buffer_r[i], buffer_lmp[i] = [], [], [], []
    
    # episode ends        
    all_ep_r.append(ep_r)

    # if np.sum(ep_r) >= 110:
    #     break

    print(
        'Ep: %i' % ep,
        '| Time:', '%.2f'%(time.time()-t2),
        '| Rtot: %.2f' % np.sum(ep_r)
    )

plt.figure(figsize = (20,6))
grid = plt.GridSpec(2, 5, wspace=0.22, hspace=0.36)
# x = range(EP_MAX)
plt.subplot(grid[0,0]) 
plt.plot(np.array(all_ep_r)[:,0])
plt.subplot(grid[0,1]) 
plt.plot(np.array(all_ep_r)[:,1])
plt.subplot(grid[0,2]) 
plt.plot(np.array(all_ep_r)[:,2])
plt.subplot(grid[0,3])
plt.plot(np.array(all_ep_r)[:,3])
plt.subplot(grid[0,4])
plt.plot(np.array(all_ep_r)[:,4])
plt.subplot(grid[1,0])
plt.plot(np.array(all_ep_r)[:,5])
plt.subplot(grid[1,1])
plt.plot(np.array(all_ep_r)[:,6])
plt.subplot(grid[1,2])
plt.plot(np.array(all_ep_r)[:,7])
plt.subplot(grid[1,3])
plt.plot(np.array(all_ep_r)[:,8])
plt.subplot(grid[1,4])
plt.plot(np.array(all_ep_r)[:,9])
plt.show()
